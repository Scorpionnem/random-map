TODO LIST

Gamemodes:
    -Capture the flag
    -FFA / FFA en team
    -


Settings:
    -Which loottable (blocks / items / useless items)